# ALL-DEMENSIONS
# Bible_01_Universe.md
## Developer Edition
## Version 2.0

# 1. PURPOSE

Diese Bible definiert die universellen Systeme, Datenmodelle und Regeln der Realität.

Zielgruppe:
- Gameplay Programmer
- World Generation Programmer
- AI Programmer
- Technical Designer
- Narrative Designer

Diese Bible ist die technische Grundlage für:
- World Generation
- NPC System
- Creature System
- Frakturzeit
- Kollapssystem
- Rekonstruktionssystem

---
# 2. SYSTEM HIERARCHY

FULL_MDD
 -> MDD
 -> GDD
 -> Universe Bible
 -> Alle weiteren Bibles

Die Universe Bible definiert die unveränderlichen Regeln des Universums.

---
# 3. CORE AXIOMS

AXIOM_01
RealityExistsIndependentOfPlayer = true

AXIOM_02
UniverseIsNotCharacter = true

AXIOM_03
MemoriesInfluenceReality = true

AXIOM_04
ConsistencyIsMeasurable = true

AXIOM_05
NothingIsFullyLost = true

AXIOM_06
ReconstructionIsPossible = true

AXIOM_07
PlayerCannotPermanentlyDie = true

---
# 4. GLOBAL DATA MODEL

UniverseState
{
WorldSeed
WorldAge
WorldTimeDays
CollapseLevel
MemoryIntegrity
FractureLevel
UniverseStability
CurrentCollapsePhase
}

WorldSeed
Type: int64

WorldTimeDays
Type: float
Range: 0-100

CollapseLevel
Type: float
Range: 0.0-1.0

MemoryIntegrity
Type: float
Range: 0.0-1.0

FractureLevel
Type: float
Range: 0.0-1.0

UniverseStability
Type: float
Range: 0.0-1.0

---
# 5. CONSISTENCY SYSTEM

Purpose:
Misst Stabilität einer Existenz.

Data Type:
float

Range:
0.0 - 1.0

Used By:
- Regions
- NPCs
- Creatures
- Objects
- Memories

Thresholds:

0.00-0.20
Critical

0.21-0.50
Unstable

0.51-0.80
Partial Stable

0.81-1.00
Stable

Effects:
Low Consistency increases:
- ReconstructionChance
- AnomalyChance
- IdentityErrors

---
# 6. MEMORY SYSTEM

MemoryIntegrity
Type: float

Range:
0.0-1.0

1.0 = vollständiges Vergessen
0.0 = vollständige Erinnerung

MemoryIntegrity beeinflusst:
- NPC Verhalten
- Kollapsintensität
- Anomalien
- Rekonstruktionen

---
# 7. RECONSTRUCTION SYSTEM

Beschreibung:
Verlorene Informationen werden rekonstruiert.

Targets:
- Region
- NPC
- Creature
- Event

Formula:
ReconstructionChance = f(
Consistency,
CollapseLevel,
MemoryIntegrity
)

Rekonstruktionen sind niemals perfekt.

Jede Rekonstruktion enthält Fehler.

---
# 8. ANOMALY SYSTEM

Anomaly Types

AM_MEMORY
AM_TIME
AM_IDENTITY
AM_GEOMETRY
AM_PHYSICS

Probability:
baseChance * CollapseLevel * RegionalModifier

---
# 9. TIME MODEL

System A
World Time

100 reale Tage.

Läuft auch wenn Spiel geschlossen ist.

System B
Fracture Time

Interne Zeitstörung.

Keine physische Karte.

Trigger:
- Collapse Threshold
- Region Events
- Narrative Events

Output:
TimeOffset

TimeOffset Range:
1 Stunde bis mehrere Jahre.

Richtung:
Nur Zukunft.

---
# 10. PLAYER MODEL

Entity:
MemoryBearer

Permanent:
true

DeleteAllowed:
false

Exception:
Final Transcendence Event

Death:
CreatesMemoryShift

---
# 11. MEMORY SHIFT SYSTEM

Class:
MemoryShift

Triggered By:
Player Death

Possible Outputs:
- New Region State
- New Time State
- New Reconstruction State

GameOver:
false

---
# 12. COLLAPSE SYSTEM

Origin:
TheWound

Expansion Method:
Graph Propagation

Influences:
- Regions
- NPCs
- Creatures
- Physics
- Reconstruction

Phases:
P1 Stable
P2 Distortion
P3 Reconstruction
P4 Fracture
P5 Collapse

---
# 13. THE WOUND

Internal ID:
REGION_WOUND

Required:
true

TimeEnabled:
false

CollapseEnabled:
false

AgingEnabled:
false

Purpose:
Final Reality State

---
# 14. END STATES

END_TRANSCENDENCE

Result:
Memory Removed
Wound Closed
Reality Stabilized

END_PERSISTENCE

Result:
Memory Retained
Wound Open
Reality Collapse Complete

---
# 15. READ / WRITE AUTHORITY

Writes UniverseState:
- CollapseSystem
- TimeFractureSystem
- ReconstructionSystem

Reads UniverseState:
- NPCSystem
- AISystem
- DialogueSystem
- WorldGenerator
- SaveSystem

---
# 16. FORBIDDEN IMPLEMENTATIONS

Forbidden:
- Gods
- Chosen One Prophecy
- Good vs Evil Core Plot
- Human Civilizations
- Classical Fantasy Races
- Permanent Player Death

---
# 17. SUCCESS CRITERION

Nach Lesen dieser Bible muss ein Entwickler erklären können:

- Was Konsistenz ist
- Was Erinnerung ist
- Was Rekonstruktion ist
- Was Frakturzeit ist
- Was Kollaps ist
- Was die Wunde ist
- Welche Systeme diese Daten verwenden
